//cmb_id_preview_title

jQuery(document).ready(function ($) {
	
/* we'll do some stuffs here */


	var cardType = $('#twitterCardType').val();
	
	// 1 - on change card type
	$( '#twitterCardType' ).change(function() {
		
		if ( cardType == 'summary' ) {
		
		
		} else if ( cardType == 'summary_large_image' ) {
		
		
		} else if ( cardType == 'photo' ) {
		
		
		} else if ( cardType == 'product' ) {
		
		
		} else if ( cardType == 'gallery' ) {
		
		
		} else if ( cardType == 'player' ) {
		
		
		} else {
		
		
		}
		
	});
		
	
});